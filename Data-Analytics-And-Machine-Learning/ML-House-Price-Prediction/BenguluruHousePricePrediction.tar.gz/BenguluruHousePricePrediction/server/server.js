// jshint esversion:6

const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const {spawn} = require('child_process');
const path = require('path');
const { Console } = require('console');

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({extended:true}));

app.get('/', function(req,res){
    res.send('<h1>Hello, World!</h1>');
});

app.post("/result",(req,res)=>{
    const {area, bedrooms,bath,location} = req.body;

    try {
        const pyScript = spawn('python3', [ "-u",path.join(__dirname + '/pyscripts/model.py'), area,bedrooms,bath,location]);
        pyScript.stdout.on('data',(data) => {
            const dataPrice = parseFloat(data)
            if(isNaN(dataPrice)){
                res.send({price:data.toString()});
            }else{
                res.send({price:dataPrice+" lakhs"});
            }
        });
        pyScript.stderr.on('data',(data) => {
            console.log(data.toString());
        });

        pyScript.on('close',(code)=>{
            null;
        });

    } catch (error) {
        console.log(error);
    }
})
const portNumber = process.env.PORT || 8080;
app.listen(portNumber, function(){
    console.log(`Server running on port ${portNumber}`);
});