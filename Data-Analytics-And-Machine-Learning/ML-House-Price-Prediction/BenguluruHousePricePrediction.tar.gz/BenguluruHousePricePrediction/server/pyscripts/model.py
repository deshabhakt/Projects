import pickle
import numpy as np
import json
import sys
import os
import requests
model = None

fullPath = os.path.join(os.path.dirname(__file__))

with open( os.path.join(fullPath,'banglore_home_prices_model.pickle'), 'rb') as file:
    model = pickle.load(file)
file.close()

column_heads = None
locations = None
with open( os.path.join(fullPath,"columns.json"), "r") as f:
    column_heads = json.load(f)['data_columns']
    locations = column_heads[3:]
f.close()


def predict_price(Area, BHK, Bathrooms, Location):
    Area = int(Area)
    BHK = int(BHK)
    Bathrooms = int(Bathrooms)
    if(BHK == 0 or BHK > 5 or Bathrooms == 0 or Bathrooms > 5 or Location == '' or Area == 0):
        return 'Invalid Input'
    elif(Area/BHK<300):
        return "Too small House!"
    loc_index = column_heads.index(Location.lower())
    if(loc_index==-1):
        return "Invalid Input"

    x = np.zeros(len(column_heads))
    x[0] = Area
    x[1] = Bathrooms
    x[2] = BHK
    if loc_index >= 0:
        x[loc_index] = 1
    price =  model.predict([x])[0].__round__(2)
    return price
price = predict_price(sys.argv[1],sys.argv[2],sys.argv[3],sys.argv[4])
print(price)
