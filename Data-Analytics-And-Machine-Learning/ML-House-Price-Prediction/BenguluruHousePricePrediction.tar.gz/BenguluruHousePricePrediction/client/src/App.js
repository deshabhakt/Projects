import React from "react";
import TitleSection from "./components/TitleSection";
import InputForm from "./components/InputForm";

function App() {
  return (
    <div className="App">
      <InputForm />
      <TitleSection />
    </div>
  );
}

export default App;
