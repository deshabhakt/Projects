import React from "react";
import ContactBar from "./ContactBar";

function Footer() {
    
    return (
        <div className="title-section">
            <h1 className="title">
                House Price Prediction in Benguluru City Using Machine Learning
            </h1>

            <ContactBar/>
        </div>);
}

export default Footer;