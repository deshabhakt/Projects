import React from "react";
import SwitchField from "./SwitchField";
import locationsJSON from "../artifacts/columns.json";
import $ from "jquery";
import has from "lodash";


function InputForm(props) {
    const inputArr = [1, 2, 3, 4, 5];
    const locations = locationsJSON.data_columns.splice(3).map(element => (<option value={has.startCase(element)} key={element}>{has.startCase(element)}</option>));

    const [locs, setLocs] = React.useState([...locations]);
    const [inputParams, setInputParams] = React.useState({
        area: 0,
        bedrooms: 0,
        bath: 0,
        location: "",
    });
    const [price, setPrice] = React.useState("");

    const [priceStyle,setPriceStyle] = React.useState({
        color:"white",
        paddingTop: "6px"
    });

    function onClickedEstimatePrice(event) {
        event.preventDefault();
        // Send data to server i.e. POST
        if (inputParams.area === 0 || inputParams.area === '' || inputParams.bath === 0 || inputParams.bedrooms === 0 || inputParams.location === '') {
            setPrice("Oops! It seems you missed some inputs 🤔");
            setPriceStyle(prevVal=>({...prevVal,color:"#DC2D5D"}));
        } else {
            $.ajax({
                url: 'http://localhost:3000/result',
                method: 'POST',
                datatype: "jsonp",
                data: inputParams,
                success: (res) => {
                    const recPrice = String(res.price);
                    if (isFinite(recPrice)) {
                        setPrice(res.price)
                        setPriceStyle(prevVal=>({...prevVal,color:"#DC2D5D"}));
                    }
                    else {
                        priceStyle.color = "red";
                        setPrice("Area too small!   Each bedroom should be atleast 300sqft in size")
                    }
                }
            });
        }

        // // Get Data from server i.e. GET or FETCH        
        // $.ajax({
        //     url: 'http://localhost:3000/result',
        //     method: 'get',
        //     success: (res) => setPrice(res.price)
        // })
    }

    function onTextInputChanged(event) {
        const onInputChange = event.target.name;
        const inputVal = event.target.value;
        setInputParams(prevVal => ({ ...prevVal, [onInputChange]: inputVal }));
        setLocs(prevVal => prevVal);
    }

    function onNumInputChanged(name, index) {
        setInputParams(prevVal => ({ ...prevVal, [name]: index + 1 }));
    }


    return (
        <div className="input-form">
            <div className="form">
                <h2>Enter Area (Square Feet)</h2>
                <input className="area floatLabel" type="text" id="uiSqft" name="area" placeholder="Enter area in square feet" onChange={onTextInputChanged} value={inputParams.area} />
                <h2>Select Number of Bedrooms</h2>
                <SwitchField inputArray={inputArr} name="bedrooms" onNumInputChanged={onNumInputChanged} />
                <h2>Select Number of Bathrooms</h2>
                <SwitchField inputArray={inputArr} name="bath" onNumInputChanged={onNumInputChanged} />
                <h2>Select Location</h2>
                <select className="location" name="location" id="uiLocations" onChange={onTextInputChanged} value={inputParams.location}>
                    <option defaultValue>Chose a Location</option>
                    {locs}
                </select>
                <form onSubmit={onClickedEstimatePrice}>
                    <input type="hidden" value={inputParams} name="params" />
                    <button className="submit" type="submit">Estimate Price</button>
                </form>
                <div id="uiEstimatedPrice" className="result">
                    <h2 placeholder=" " style={priceStyle}>{price}</h2>
                </div>
            </div>
        </div>)
}


export default InputForm;