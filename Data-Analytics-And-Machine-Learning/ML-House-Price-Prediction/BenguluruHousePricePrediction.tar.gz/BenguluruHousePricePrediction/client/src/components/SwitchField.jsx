import React from "react";

function SwitchField(props) {

    const inputs = props.inputArray;
    const [inputState, setInputState] = React.useState([0, 0, 0, 0, 0]);
    function onClicked(index) {
        setInputState(prevVal => {
            return prevVal.map((element, i) => {
                if (i === index) {
                    return !element;
                } else {
                    return false;
                }
            });
        })
    }
    return (
        <form className="switch-field">
            {inputs.map((element, index) => {
                return (
                    <p onClick={() => {
                        props.onNumInputChanged(props.name,index)
                        onClicked(index)
                    }} style={{ backgroundColor: inputState[index] ? "green" : "" }} className="label" key={index}
                    >
                        {element}
                    </p>
                )
            })}
        </form>
    )
}

export default SwitchField;