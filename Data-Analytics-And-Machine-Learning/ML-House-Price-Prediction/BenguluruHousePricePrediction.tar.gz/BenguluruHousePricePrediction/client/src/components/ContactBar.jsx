import React from "react";

function ContactBar() {
    const year = new Date().getFullYear();
    const devName = "Deshabhakt Gavali";
    return (
        <div className="contact-bar font-small">
            <a className="col" href="https://www.linkedin.com/in/deshabhakt-gavali-6ba5b414a/">
                <img id='logo' src='https://image.flaticon.com/icons/png/512/174/174857.png' alt='linkedin' />
            </a>
            <a className="col" href="https://www.github.com/deshabhakt/"><img id='logo'
                src='https://image.flaticon.com/icons/png/512/1051/1051326.png' alt='github' /></a>
            <a className="col" href="https://www.facebook.com/deshabhakt5/"><img id='logo'
                src='https://image.flaticon.com/icons/png/512/733/733547.png' alt='facebook' />
            </a>
            <a className="col" href="https://www.instagram.com/deshabhakt/"><img id='logo'
                src='https://image.flaticon.com/icons/png/512/2111/2111463.png' alt='instagram' /></a>
            <div className="footer-a-tag py-2">&copy; {year} : <a className="footer-a-tag" href="https://www.github.com/deshabhakt">{devName}</a>
            </div>
        </div>
    );
}

export default ContactBar;